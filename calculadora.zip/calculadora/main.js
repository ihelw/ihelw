var calc={

texto1:document.getElementById('txt1').value,
texto2:document.getElementById('txt2').value,
resul:"",

somarValores: function(){
        this.resul = this.texto1 + this.texto2;
        return this.resul;
    },

    subtrairValores: function(){
            this.resul = this.texto1.valueOf() - this.texto2.valueOf();
            return this.resul;
        },

        multiplicarValores: function(){
                this.resul = this.texto1.valueOf() * this.texto2.valueOf();
                return this.resul;
            },

            dividirValores: function(){
                    this.resul = this.texto1.valueOf() / this.texto2.valueOf();
                    return this.resul;
                }

};


document.getElementById('somar').onclick = function(){
document.getElementById('resultado').innerHTML = "Resultado: " + calc.somarValores();
}

document.getElementById('sub').onclick = function(){
document.getElementById('resultado').innerHTML = "Resultado: " + calc.subtrairValores();
}

document.getElementById('div').onclick = function(){
document.getElementById('resultado').innerHTML = "Resultado: " + calc.dividirValores();
}

document.getElementById('mul').onclick = function(){
document.getElementById('resultado').innerHTML = "Resultado: " + calc.multiplicarValores();
}
